g++ interrupts.cpp -I interrupts.hpp -o test_trace12.o
./test_trace12.o<<EOF 
vector_table.txt
test_trace12.txt
execution_test12
EOF 