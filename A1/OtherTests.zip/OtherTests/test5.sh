g++ interrupts.cpp -I interrupts.hpp -o test_trace5.o
./test_trace5.o<<EOF 
vector_table.txt
test_trace5.txt
execution_test5
EOF 