g++ interrupts.cpp -I interrupts.hpp -o test_trace4.o
./test_trace4.o<<EOF 
vector_table.txt
test_trace4.txt
execution_test4
EOF 