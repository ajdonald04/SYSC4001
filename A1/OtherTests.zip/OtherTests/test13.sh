g++ interrupts.cpp -I interrupts.hpp -o test_trace13.o
./test_trace13.o<<EOF 
vector_table.txt
test_trace13.txt
execution_test13
EOF 