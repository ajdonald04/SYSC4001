g++ interrupts.cpp -I interrupts.hpp -o test_trace6.o
./test_trace6.o<<EOF 
vector_table.txt
test_trace6.txt
execution_test6
EOF 