g++ interrupts.cpp -I interrupts.hpp -o test_trace10.o
./test_trace10.o<<EOF 
vector_table.txt
test_trace10.txt
execution_test10
EOF 