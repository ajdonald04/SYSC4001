g++ interrupts.cpp -I interrupts.hpp -o test_trace1.o
./test_trace1.o<<EOF 
vector_table.txt
test_trace1.txt
execution_test1
EOF 

    
