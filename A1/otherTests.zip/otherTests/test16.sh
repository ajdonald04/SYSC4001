g++ interrupts.cpp -I interrupts.hpp -o test14.o 
./test_trace14.o<<EOF 
vector_table.txt
test_trace14.txt
execution_test14
EOF 